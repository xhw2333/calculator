# 小学四则运算器

​	此项目为软工作业，采用electron+html+css+js实现，electron提供打包成exe文件。该项目可以供给小学生做题，熟悉四则运算